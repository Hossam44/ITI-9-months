﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Ataal.BL.DtO.Identity
{
    public record LoginDto(string UserName, string Password);
}
