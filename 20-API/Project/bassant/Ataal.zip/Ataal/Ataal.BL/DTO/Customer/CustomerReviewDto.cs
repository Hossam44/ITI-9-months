﻿using System;
using System.Collections.Generic;
using System.Linq;


namespace Ataal.BL.DtO.Customer
{
    public record CustomerReviewDto(int id, string name, byte[]? Photo);
}
