﻿namespace Ataal.BL;

public static class Constants
{
    public static class Roles
    {
        public const string Admin = "Admin";
        public const string Customer = "Customer";
        public const string Technical = "Technical";
    }
}
