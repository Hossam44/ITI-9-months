﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Ataal.BL.DtO.Section
{
    public record Section_Name_And_Id_DtO(int id, string Name);
}
