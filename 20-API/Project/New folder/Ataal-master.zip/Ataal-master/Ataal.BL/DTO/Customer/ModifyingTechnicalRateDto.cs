﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ataal.BL.DTO.Customer
{
    public record ModifyingTechnicalRateDto(int TechnicalId, int RateValue);
    
}
